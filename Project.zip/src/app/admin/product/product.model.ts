export class productmodel{
    id :number =0;
    productName :string ='';
    productPrice :string ='';
    productDescription :string ='';
    image :string ='';
  url: any;


}