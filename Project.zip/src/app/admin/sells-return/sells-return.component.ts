import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sells-return',
  templateUrl: './sells-return.component.html',
  styleUrls: ['./sells-return.component.css']
})
export class SellsReturnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
