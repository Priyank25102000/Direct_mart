import { Component, Input, OnInit } from '@angular/core';
import { CartService } from 'src/app/service/cart.service';
import { CartComponent } from '../cart/cart.component';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {

  
  public product :any =[];
  public grandtotal! :number;
  @Input() productlist = [];

  constructor(private cartservice :CartService) { }

  ngOnInit(): void {
    this.cartservice.getproduct()
    .subscribe(res=>{
      this.product =res;
      this.grandtotal =this.cartservice.gettotalprice();   
    })
    
  }
}