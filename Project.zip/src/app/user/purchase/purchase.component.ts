import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from 'src/app/service/cart.service';
import { CartComponent } from '../cart/cart.component';

@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.css']
})
export class PurchaseComponent implements OnInit {


confirm = false;
payment = true;

  constructor(private router: Router) { }

  ngOnInit(): void {
   
  }

  
click(){
    this.confirm = true;
    this.payment = false;

  }
}
